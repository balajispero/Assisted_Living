<!DOCTYPE html>
<html lang="en">
  
<head>
<head>

    <meta charset="utf-8">
    <title><?php echo $companyInfo->company_name;?> | Log in</title>

	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <meta name="apple-mobile-web-app-capable" content="yes"> 
    
<link href="<?php echo base_url()?>public/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
        <!-- <link href="<?php echo base_url();?>public/css/font-awesome.min.css" rel="stylesheet" type="text/css" /> -->
        <!-- <link href="<?php echo base_url();?>public/css/ionicons.min.css" rel="stylesheet" type="text/css" /> -->
        <!-- <link href="<?php echo base_url();?>public/css/AdminLTE.css" rel="stylesheet" type="text/css" /> -->

</head><div style="position:fixed; bottom: 0; right: 0; width: 67%; border: 2px solid #CCC; top:200px; z-index:1001; background-color: #FFF; display:none;" id="ad2">
    <span style="right: 0; position: fixed; cursor: pointer; z-index:1002" onclick="closeAd('ad2')" >CLOSE</span>
    <script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- Payroll Management System -->
<ins class="adsbygoogle"
     style="display:block"
     data-ad-client="ca-pub-3182624105910612"
     data-ad-slot="4635770289"
     data-ad-format="auto"></ins>
<script>
(adsbygoogle = window.adsbygoogle || []).push({});
</script>


<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- Assisted Living -->
<ins class="adsbygoogle"
     style="display:block"
     data-ad-client="ca-pub-3182624105910612"
     data-ad-slot="3101991489"
     data-ad-format="auto"></ins>
<script>
(adsbygoogle = window.adsbygoogle || []).push({});
</script>


<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- Grading System -->
<ins class="adsbygoogle"
     style="display:block"
     data-ad-client="ca-pub-3182624105910612"
     data-ad-slot="6132191885"
     data-ad-format="auto"></ins>
<script>
(adsbygoogle = window.adsbygoogle || []).push({});
</script>

<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- HMS Website -->
<ins class="adsbygoogle"
     style="display:block"
     data-ad-client="ca-pub-3182624105910612"
     data-ad-slot="1562391480"
     data-ad-format="auto"></ins>
<script>
(adsbygoogle = window.adsbygoogle || []).push({});
</script>
</div>

<body>

    
<style type="text/css">
	.header-icon {
		font-family: "trebuchet";
		font-size: 14px;
		color: #E9893D;
		font-weight: bold;
		margin-top: 2px;
	}

	.content-icon {
		font-family: "trebuchet";
		font-weight: bold;
		color: #0171D5;
	}

	.powered{
		margin-top: 50px;
		font-family: "trebuchet";
		font-weight: bold;
		color: #0171D5;
		font-size: 10px;
	}

	.login-icon{
		font-size: 12px;
		font-family: "trebuchet";
	}
</style>




<div class="row">

<br><br><br><br><br><br><br><br>
<center>
	<img src="<?php echo base_url()?>public/img/expiration-img.jpg">
	<br><br><br><br>
Powered by: <a href="http://grafikspointdesign.com/" target="_blank">GrafiksPoint Design</a>
</center>

</div>
	



<script src="<?php echo base_url()?>public/login/js/bootstrap.js"></script>

<script src="<?php echo base_url()?>public/login/js/signin.js"></script>

</body>

</html>
