<style>
    @media only screen and (min-width: 768px)
    {
        input {
          width:100% !important;  
      }
      select {
          width:100% !important;  
      }
      .genexminput {
          width:60% !important;  
      }
      textarea[name="patient_iden"]
      {
        width: 100% !important;
    }
    textarea[name="noofhouse"]
    {
        width: 100% !important;
    }
    .dis_flex {
                display: flex;
            }
            .btn.btn-circle {
                margin-top: 7px;
            }
} 
@media only screen and (min-width: 1024px)
{    
    input {
      width:50% !important;  
  }
  select {
      width:50% !important;  
  }
              /*textarea {
                  width:50% !important;  
              }*/
              .genexminput {
                  width:50% !important;  
              }
              input[name="ptn_pulse"]
              {
                width: 100% !important;
            }
            input[name="ptn_bp"]
            {
                width: 100% !important;
            }
            input[name="ptn_spo2"]
            {
                width: 100% !important;
            }
            input[name="ptn_temp"]
            {
                width: 100% !important;
            }
            input[name="ptn_cvs"]
            {
                width: 59% !important;
            }
            input[name="ptn_cns"]
            {
                width: 59% !important;
            }
            textarea[name="patient_iden"]
            {
                width: 50% !important;
            }
            textarea[name="noofhouse"]
            {
                width: 50% !important;
            }
            textarea[name="allergies"]
            {
                width: 100% !important;
            }
            textarea[name="warnings"]
            {
                width: 59% !important;
            }

        }
        @media only screen and (min-width: 1326px)
        {    
            input {
              width:50% !important;  
          }
          select {
              width:50% !important;  
          }
          textarea {
              width:50% !important;  
          }
          .genexminput {
              width:50% !important;  
          }
          textarea[name="ptn_kco"]
          {
            width: 100% !important;
        }
        textarea[name="ptn_fam_his"]
        {
            width: 100% !important;
        }
        textarea[name="ptn_pa"]
        {
            width: 100% !important;
        }
        textarea[name="ptn_foodin"]
        {
            width: 100% !important;
        }

        textarea[name="ptn_chf_comp"]
        {
            width: 59% !important;
        }
        textarea[name="ptn_past_his"]
        {
            width: 59% !important;
        }
        textarea[name="ptn_localex"]
        {
            width: 59% !important;
        }
        textarea[name="ptn_um"]
        {
            width: 59% !important;
        }
        textarea[name="ptn_rs"]
        {
            width: 59% !important;
        }
        textarea[name="allergies"]
        {
            width: 100% !important;
        }
        textarea[name="warnings"]
        {
            width: 59% !important;
        }

    }    
    @media only screen and (min-width: 320px) and (max-width: 425px)
    { 
        input {
          width:100% !important;
      }
      select {
          width:100% !important;  
      }
      .genexminput {
          width:59% !important;  
      }
      #ptn_cvs,#ptn_cns {
        width: 60% !important;
    }
    .dis_flex {
                display: flex;
            }
            .btn.btn-circle {
                margin-top: 7px;
            }

}
</style>